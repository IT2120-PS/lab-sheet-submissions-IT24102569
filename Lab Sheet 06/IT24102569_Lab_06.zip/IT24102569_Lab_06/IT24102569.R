setwd("C:\\Users\\Gw\\Desktop\\IT24102569")


# Question 1: sub Question ii

n <- 50
p <- 0.85
cat("X ~ Binomial(50, 0.85)\n")

prob_at_least_47 <- sum(dbinom(47:50, size=n, prob=p))
prob_at_least_47


# Question 2: sub Question i
lambda <- 12
prob_15 <- dpois(15, lambda)
prob_15






