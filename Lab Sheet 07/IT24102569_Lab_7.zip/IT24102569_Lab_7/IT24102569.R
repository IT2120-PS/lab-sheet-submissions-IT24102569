setwd("C://Users//Gw//Desktop//IT24102569_Lab_7")

# Question 1
min_time <- 0
max_time <- 40
prob_uniform <- punif(25, min_time, max_time) - punif(10, min_time, max_time)
print(prob_uniform)


# Question 2
lambda <- 1
prob_exp <- pexp(2, rate = lambda)
print(prob_exp)


# Question 3 : sub question 1
mean_iq <- 100
sd_iq <- 15
prob_iq_above_130 <- 1 - pnorm(130, mean = mean_iq, sd = sd_iq)
print(prob_iq_above_130)


# Question 3 : sub question 2
iq_95 <- qnorm(0.95, mean = mean_iq, sd = sd_iq)
print(iq_95)




